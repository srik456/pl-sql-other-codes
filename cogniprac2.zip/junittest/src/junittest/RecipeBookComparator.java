package junittest;

public class RecipeBookComparator {

}
