package junittest;
import java.util.*;
public class RecipeBook {
	private ArrayList<Recipe>rList;
	public RecipeBook(){
		rList=new ArrayList<>();
	}
	public boolean addRecipe(Recipe recipe){
		boolean flag;
		for(Recipe r:rList){
			if(r.equals(recipe)){
				return false;
			}
		}
		flag=rList.add(recipe);
		return flag;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rList == null) ? 0 : rList.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecipeBook other = (RecipeBook) obj;
		if (rList == null) {
			if (other.rList != null)
				return false;
		} else if (!rList.equals(other.rList))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "RecipeBook rList=" + rList ;
	}
	public void showRecipes(){
		for(Recipe r:rList){
			System.out.println(r);
		}
	}
    public boolean deleteRecipe(String rname){
    	for(Recipe R:rList){
    		if(R.getName().equals(rname)){
    			rList.remove(R);
    			return true;
    		}
    	}
    	return false;
    }
}
