package junittest;

public class Recipe {
	private String name;
	private int price,amtCoffee,amtMilk,amtSugar,amtChocolate;
	public Recipe(String name, int price, int amtCoffee, int amtMilk, int amtSugar, int amtChocolate) {
		super();
		this.name = name;
		this.price = price;
		this.amtCoffee = amtCoffee;
		this.amtMilk = amtMilk;
		this.amtSugar = amtSugar;
		this.amtChocolate = amtChocolate;
	}
	
	public Recipe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(String price1) throws RecipeException{
		 int price=0;
	        try{
	        	price=Integer.parseInt(price1);
	        }catch(NumberFormatException e){
	        	throw new RecipeException("Units of price must be positive");
	        }
	        if(price>=0){
	        	this.price=price;
	        }
	        else{
	        	throw new RecipeException("Units of price must be positive");
	        }
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amtChocolate;
		result = prime * result + amtCoffee;
		result = prime * result + amtMilk;
		result = prime * result + amtSugar;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + price;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recipe other = (Recipe) obj;
		if (amtChocolate != other.amtChocolate)
			return false;
		if (amtCoffee != other.amtCoffee)
			return false;
		if (amtMilk != other.amtMilk)
			return false;
		if (amtSugar != other.amtSugar)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (price != other.price)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Recipe name=" + name + ", price=" + price + ", amtCoffee=" + amtCoffee + ", amtMilk=" + amtMilk
				+ ", amtSugar=" + amtSugar + ", amtChocolate=" + amtChocolate;
	}

	public int getAmtCoffee() {
		return amtCoffee;
	}
	public void setAmtCoffee(String Coffee) throws RecipeException {
		 int amtCoffee=0;
	        try{
	        	amtCoffee=Integer.parseInt(Coffee);
	        }catch(NumberFormatException e){
	        	throw new RecipeException("Units of coffee must be positive");
	        }
	        if(amtCoffee>=0){
	        	this.amtCoffee=amtCoffee;
	        }
	        else{
	        	throw new RecipeException("Units of coffee must be positive");
	        }
	}
	public int getAmtMilk() {
		return amtMilk;
	}
	public void setAmtMilk(String Milk) throws RecipeException{
		int amtMilk=0;
        try{
        	amtMilk=Integer.parseInt(Milk);
        }catch(NumberFormatException e){
        	throw new RecipeException("Units of milk must be positive");
        }
        if(amtMilk>=0){
        	this.amtMilk=amtMilk;
        }
        else{
        	throw new RecipeException("Units of milk must be positive");
        }
}
	
	public int getAmtSugar() {
		return amtSugar;
	}
	public void setAmtSugar(String Sugar) throws RecipeException{
		//this.amtSugar = amtSugar;
		int amtSugar=0;
        try{
        	amtSugar=Integer.parseInt(Sugar);
        }catch(NumberFormatException e){
        	throw new RecipeException("Units of sugar must be positive");
        }
        if(amtSugar>=0){
        	this.amtSugar=amtSugar;
        }
        else{
        	throw new RecipeException("Units of sugar must be positive");
        }
	}
	public int getAmtChocolate() {
		return amtChocolate;
	}
	public void setAmtChocolate(String chocolate) throws RecipeException{
        int amtChocolate=0;
        try{
        	amtChocolate=Integer.parseInt(chocolate);
        }catch(NumberFormatException e){
        	throw new RecipeException("Units of chocolate must be positive");
        }
        if(amtChocolate>=0){
        	this.amtChocolate=amtChocolate;
        }
        else{
        	throw new RecipeException("Units of chocolate must be positive");
        }
	}
	
	
	

}
