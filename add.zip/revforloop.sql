begin
 for i in reverse 1..5 loop
 dbms_output.put_line('i'||i);
 end loop;
 end;
/
