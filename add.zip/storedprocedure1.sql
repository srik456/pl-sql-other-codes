create or replace procedure hello
as
begin
dbms_output.put_line('Hello world');
end;
/
