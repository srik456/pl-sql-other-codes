create or replace procedure getsquare(a in number,sqr out number)
as
begin
sqr:=a*a;
end;
/
