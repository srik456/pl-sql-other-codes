package corejava1;

public class SavingsAccount extends Account{
	private boolean isSenior;

	public SavingsAccount() {
		// TODO Auto-generated constructor stub
		super();
	}

	/*public SavingsAccount(boolean isSenior) {
		super();
		this.isSenior = isSenior;
	}*/
	
	public SavingsAccount(int acno, String name, float balance, boolean isSenior) {
		super(acno, name, balance);
		this.isSenior = isSenior;
	}

	public boolean isSenior() {
		return isSenior;
	}

	public void setSenior(boolean isSenior) {
		this.isSenior = isSenior;
	}

	public void display(){
		super.display();
		//System.out.println(getAcno()+" "+getName()+" "+getBalance());
		System.out.println("isSenior "+isSenior);
	}
	public void withdraw(float amt){
		if(balance-amt>2000){
			balance-=amt;
		}
		else{
			System.out.println("Insufficient Balance");
		}
	}
	public void deposit(float amt){
		balance = balance+amt;
		System.out.println("Amount deposited is: "+amt);
	}
	

}
