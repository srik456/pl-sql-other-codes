package dateexercise;
import java.util.*;
import java.time.*;
public class LDExercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String d1,d2;
     Scanner s=new Scanner(System.in);
     
	}

}
