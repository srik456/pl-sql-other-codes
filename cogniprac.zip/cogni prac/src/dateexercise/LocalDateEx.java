package dateexercise;
import java.util.*;
import java.time.*;
public class LocalDateEx {

	static void createDate(){
		LocalDate today=LocalDate.now();
		System.out.println(today);
		LocalDate someDate=LocalDate.of(2004,Month.AUGUST,17);
		LocalDate someOtherDate=LocalDate.of(2019, Month.JANUARY, 12);
		System.out.println(someOtherDate);
		LocalDate newOtherDate=LocalDate.parse("2022-05-12");
		System.out.println(newOtherDate);
        System.out.println("--------------------");		
	}
	static void getDateInfo(){
		LocalDate someDate=LocalDate.of(2019,2,22);
		System.out.println("Year "+someDate.getYear());
		Month m=someDate.getMonth();
		System.out.println("Month "+someDate.getMonth()+" "+m);
		System.out.println("Date "+someDate.getDayOfMonth());
		DayOfWeek dw=someDate.getDayOfWeek();
		System.out.println("Name of Day Of Week "+dw);
		System.out.println("Day "+dw.getValue());
		
	}
	static void addyear(){
		LocalDate date
	}
	static void subtractyear(){
		
	}
	static void addMonth(){
		
	}
	static void addDay(){

    }
	static void dateToLocaleDate(){
		
	}
	static void formatDate(){
		
	}
