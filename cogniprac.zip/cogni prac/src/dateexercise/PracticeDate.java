package dateexercise;
import java.util.*;

public class PracticeDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int thour,tmin,tsec,ahour,amin,asec;
		Calendar t1=Calendar.getInstance();
		Calendar t2=Calendar.getInstance();
		t1.set(Calendar.HOUR,2);
		t1.set(Calendar.MINUTE, 35);
		t1.set(Calendar.SECOND, 25);
		t2.set(Calendar.HOUR, 8);
		t2.set(Calendar.MINUTE, 8);
		t2.set(Calendar.SECOND, 50);
		tsec=t1.get(Calendar.SECOND)+t2.get(Calendar.SECOND);
		asec=tsec%60;
		tmin=t1.get(Calendar.MINUTE)+t2.get(Calendar.MINUTE);
		amin=tmin%60;
		thour=t1.get(Calendar.HOUR)+t2.get(Calendar.HOUR);
		ahour=thour%60;
		System.out.println("Total hours: "+ahour+" "+"Total Minutes: "+amin+" "+"Total Seconds: "+asec);
		

	}

}
