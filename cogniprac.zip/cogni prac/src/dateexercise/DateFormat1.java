package dateexercise;
import java.util.*;
import java.text.*;

public class DateFormat1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d=new Date();
		DateFormat df=DateFormat.getDateInstance(DateFormat.SHORT,Locale.JAPAN);
		System.out.println("Short Date "+df.format(d));
		df=DateFormat.getDateInstance(DateFormat.LONG,Locale.JAPAN);
		System.out.println("Long Date "+df.format(d));
		df=DateFormat.getDateInstance(DateFormat.DEFAULT);
		System.out.println("Default Date "+df.format(d));
		df=DateFormat.getDateInstance(DateFormat.FULL,Locale.GERMAN);
		System.out.println("Full Date "+df.format(d));
		 df=DateFormat.getDateInstance(DateFormat.MEDIUM);
		System.out.println("Medium Date "+df.format(d));
		 df=DateFormat.getDateInstance(DateFormat.LONG,Locale.GERMANY);
		System.out.println("Long Date CHN "+df.format(d));
		

	}

}
