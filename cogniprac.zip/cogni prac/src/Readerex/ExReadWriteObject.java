package Readerex;
import java.io.*;
public class ExReadWriteObject implements Serializable{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ObjectInputStream in=null;
        ObjectOutputStream out=null;
        try {
			out=new ObjectOutputStream(new FileOutputStream("emp.dat"));
			MyEmployee e=new MyEmployee(101,"Anita",15000);
			MyEmployee e1=new MyEmployee(102,"Priya",30000);
			MyEmployee e2=new MyEmployee(101,"Mahesh",100000);
			out.writeObject(e);
			out.writeObject(e1);
			out.writeObject(e2);
		} 
        
        	catch (IOException e) {
        
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally{
        	try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        try{
        	//in=new ObjectInputStream(new FileInputStream("emp.dat"));
        	FileInputStream fin=new FileInputStream("emp.dat");
        	in=new ObjectInputStream(fin);
        	while(fin.available()>0){
        		MyEmployee e4=(MyEmployee) in .readObject();
        		System.out.println(e4);
        	}
        	
        	//MyEmployee e5=(MyEmployee) in .readObject();
        	
        }
        catch (IOException e) {
            
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally{
        	try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
	}
}


