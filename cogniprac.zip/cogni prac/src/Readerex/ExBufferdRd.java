package Readerex;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExBufferdRd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader in=null;
		long start=0;
		long end=0;
		try {
			in=new BufferedReader(new FileReader("d:\\Sriktxt.txt"));
			String line;
			start=System.currentTimeMillis();
			while((line=in.readLine())!=null){
				System.out.println(line);
			}
			end=System.currentTimeMillis();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Total time "+(end-start));
		

	}

}
