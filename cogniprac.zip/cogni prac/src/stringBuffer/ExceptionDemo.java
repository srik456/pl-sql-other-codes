package stringBuffer;
import java.util.*;

public class ExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter n1");
		int n1=s.nextInt();
		System.out.println("Enter n2");
		int n2=s.nextInt();
		int result=0;
		int arr[]={1,2,3,4};
		String s1=null;
		/*try{
			result=n1/n2;
			int y=arr[result];
			System.out.println(y);
			System.out.println(s1.length());
			}
		catch(ArithmeticException e){
			//System.out.println("Please enter non-zero number");
			System.out.println(e);
			}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
		}
		catch(Exception e){
			System.out.println(e);
			
		}
		System.out.println(result);*/
		/*try{
			result=n1/n2;
			int y=arr[result];
			System.out.println(y);
			System.out.println(s1.length());
			}
		catch(ArithmeticException| ArrayIndexOutOfBoundsException e){
			//System.out.println("Please enter non-zero number");
			System.out.println(e);
			}*/
		try{
			result=n1/n2;
			int y=arr[result];
			System.out.println(y);
			System.out.println(s1.length());
			}
		catch(Exception e){
			//System.out.println("Please enter non-zero number");
			System.out.println(e);
		}
		finally{
			System.out.println("in finally block");
		}
		
		

	}

}
