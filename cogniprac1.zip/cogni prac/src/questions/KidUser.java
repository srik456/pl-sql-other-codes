package questions;

public class KidUser implements LibraryUser{
	int age;
	String bookType;
	public KidUser() {
		super();
	}

	public KidUser(int age, String bookType) {
		super();
		this.age = age;
		this.bookType = bookType;
	}

	public void registerAccount(){
		if(age<12){
			System.out.println("You have successfully registered under kids Account");
		}
		else{
			System.out.println("Sorry,age must be less than 12 to register as a kid");
		}
	}
	public void requestBook(){
		if(bookType.equals("Kids")){
			System.out.println("Book issued sucessfully please return the book within 10 days");
		}
		else{
			System.out.println("Oops,you are allowed to take only kids books");
		}
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBookType() {
		return bookType;
	}

	public void setBookType(String bookType) {
		this.bookType = bookType;
	}

}
