package questions;

public class AdultUser implements LibraryUser {
	private int age;
	private String booktype;
	public AdultUser() {
		super();
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBooktype() {
		return booktype;
	}

	public void setBooktype(String booktype) {
		this.booktype = booktype;
	}

	public AdultUser(int age, String booktype) {
		super();
		this.age = age;
		this.booktype = booktype;
	}
	public void registerAccount(){
		if(age>=12){
			System.out.println("You have successfully registered under Adult Account");
		}
		else{
			System.out.println("Sorry,age must be greater than 12 to register as a adult");
		}
	}
	public void requestBook(){
		if(booktype.equals("Fiction")){
			System.out.println("Book issued sucessfully please return the book within 7 days");
		}
		else{
			System.out.println("Oops,you are allowed to take only adult fiction books");
		}
	}
	

}
