package Readerex;
import java.io.*;
public class DirEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dname="d:\\myjava";
		File dir=new File(dname);
		dir.mkdir();
		File file=

	}

}
