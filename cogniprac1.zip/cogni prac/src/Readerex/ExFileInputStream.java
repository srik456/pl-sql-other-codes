package Readerex;
import java.io.*;
public class ExFileInputStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream in=null;
		FileOutputStream out=null;
		try {
			in=new FileInputStream("d:\\img.png");
			out=new FileOutputStream("d:\\myimg.png");
			int ch;
			while((ch=in.read())!=-1){
				out.write(ch);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				in.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		

	}

}
