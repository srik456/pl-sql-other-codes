package Readerex;

import java.io.*;

public class FileEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*File file=new File("d:\\Sriktxt.txt");
		System.out.println(file.exists()+" "+file.isFile());
		File dir=new File("d:\\736344\\Workspace");
		System.out.println(dir.exists()+" "+dir.isFile()+" "+dir.isDirectory());
		System.out.println(file.getAbsolutePath());
		System.out.println(file.getName());
		System.out.println(dir.exists()+" "+dir.isFile()+" "+dir.isDirectory());
		System.out.println(file.exists()+" "+file.isFile()+" "+file.isDirectory()+" "+file.length());*/
		File file=new File("d:\\MyFile.txt");
        BufferedWriter out=null;
        if(file.exists()){
        	try{
        		out=new BufferedWriter(new FileWriter(file,true));
        	}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        else{
        	try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        try{
        	out.write("Write the buffer :");
        	out.write("this is a first line");
        	out.write("this is a second line");
        	
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
        finally{
        	try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }

}
}
