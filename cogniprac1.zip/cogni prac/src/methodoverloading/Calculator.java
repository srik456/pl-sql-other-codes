package methodoverloading;

public class Calculator {
	public static void add(int a,int b){
		System.out.println(a+b);
	}
	public static void add(float a,float b){
		System.out.println(a+b);
	}
	public static void add(double a,double b){
		System.out.println(a+b);
	}
	

}
