package colections1;
import java.util.*;
import java.util.Arrays.*;
import java.util.Collections;
public class TestCollection {

	/*static<T,X,U> void print(T a,X b,T c){
		System.out.println(a+" "+b+" "+c);
	}*/
	static void someMethod(Object obj){
		System.out.println(obj);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*print(12,34.87d,"aaa");
		GenericDem<Integer> G=new GenericDem<>();
		G.setX(12);
		System.out.println(G.getX());
		G.setX(4567);
		System.out.println(G.getX());*/
		/*String s="abc";
		someMethod(s);
		int x=10;
		someMethod(x);
*/
        ArrayList<Integer> aList=new ArrayList<>();
        aList.add(10);
        aList.add(20);
        aList.add(30);
        aList.add(30);
        aList.add(1,11);
        aList.add(0);
        Collections.sort(aList);
       /* System.out.println(aList);*/
        /*Object[] Iarr= aList.toArray();
        for(int i=0;i<Iarr.length;i++){
        	System.out.println(Iarr[i]);
        }*/
       /* Integer xArr[]=new Integer[aList.size()];
        aList.toArray(xArr);*/
        for(int x:aList){
        	System.out.println(x);
        }
    	
       /* System.out.println("is 10 present "+aList.contains(10));
        System.out.println("index of 30 "+aList.indexOf(30));
        System.out.println("last index of 30 "+aList.indexOf(30));
        aList.remove(0);
       aList.remove(new Integer(0));*/
       /* System.out.println("after removal at index 0 "+aList);
        System.out.println(aList);*/
       /* System.out.println(aList.get(2));*/
        //Iterator
      /*  Iterator<Integer> i=aList.iterator();
        while(i.hasNext()){
        	int x=i.next();
        	System.out.println(x);
        }*/
        /*for(int x:aList){
        	System.out.println(x);
        }*/
        
	}
	

}
	
