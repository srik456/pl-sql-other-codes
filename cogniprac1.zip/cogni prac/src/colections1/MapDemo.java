package colections1;
import java.util.*;
public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,Double> hmap=new HashMap<Integer,Double>();
		hmap.put(11,120000.00);
		hmap.put(1,150000.00);
		hmap.put(12,130000.00);
		hmap.put(13,170000.00);
		hmap.put(14,180000.00);
		hmap.put(99,120000.00);
		hmap.put(1,180000.00);
		System.out.println(hmap);
		System.out.println(hmap.get(11));
		Set<Integer> keys=hmap.keySet();
		Iterator<Integer>itr=keys.iterator();
		System.out.println(keys);
		while (itr.hasNext()){
			int k=itr.next();
			Double value=hmap.get(k);
			System.out.println(value);
		}
		
		

	}

}
