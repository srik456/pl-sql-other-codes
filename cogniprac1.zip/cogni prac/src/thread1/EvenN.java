package thread1;
import java.util.*;
public class EvenN extends Thread{
private int even;
private ArrayList<Integer> al=new ArrayList<>();

public EvenN(int even, ArrayList<Integer> al) {
	super();
	this.even = even;
	this.al = al;
}

public void run(){
	for(int i=1;i<even;i++){
		if((i%2)==0){
			al.add(i);
		}
	}
	for(Integer x:al){
		System.out.println(x);
	}
	try {
		Thread.sleep(100);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
