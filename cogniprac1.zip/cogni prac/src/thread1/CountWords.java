package thread1;
import java.util.*;
import java.io.*;
public class CountWords extends Thread{
	public void run(){
		BufferedReader reader=null;
	          String line;
	        int wordcount=0;
				try{
					reader=new BufferedReader(new FileReader("d:\\Sriktxt.txt"));
					while( (line=reader.readLine())!=null ){
						String wc[]=line.split("\\s+");
						wordcount+=wc.length;
						
					}
					System.out.println(wordcount);
				}catch(FileNotFoundException e){
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally{
					try {
						reader.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
	}

	

	}


