package thread1;

public class Threaddemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//sequential execution
		/*for(int i=0;i<=5;i++){
			System.out.println(i);
		}
		System.out.println();
		for(int i=1;i<=10;i++){
			System.out.println(5*i);
		}*/
		System.out.println("Starting Main thread");
		MyThread m=new MyThread(1,12);
		//m.run();
		m.start();
		YourThread y=new YourThread(8);
		y.start();
		//y.run();
		System.out.println("before m "+m.isAlive());
		System.out.println("before y "+y.isAlive());
		try {
			m.join();
			y.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("m "+m.isAlive());
		System.out.println("y "+y.isAlive());
		System.out.println("Ending Main Thread");

	}

}
