package thread1;

public class MainCouple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Couple c1=new Couple("X","Y");
		CoupleThread c2=new CoupleThread(c1);
		
		Couple c3=new Couple("John","Jane");
		CoupleThread c4=new CoupleThread(c3);
		c2.start();
		c4.start();

	}

}
