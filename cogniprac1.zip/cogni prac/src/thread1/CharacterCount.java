package thread1;
import java.util.*;
import java.io.*;
public class CharacterCount extends Thread{
	public void run(){
		FileReader reader=null;
	        int line;
	        int charcount=0;
				try{
					reader=new FileReader("d:\\Sriktxt.txt");
					while((line=reader.read())!=-1){
						charcount++;
						
					}
					System.out.println(charcount);
				}catch(FileNotFoundException e){
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally{
					try {
						reader.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
              }
}
