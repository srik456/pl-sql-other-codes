package thread1;

public class CoupleThread extends Thread{
	private Couple c;	
	public CoupleThread(Couple c) {
		super();
		this.c = c;
	}
		
                              
		public CoupleThread() {
			super();
		}
		public void run(){
			c.show();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	

	}


