package thread1;

public class MyThread extends Thread{
    private int start,end;
	public MyThread(int start, int end) {
		super();
		this.start = start;
		this.end = end;
	}
	public void run() {
		// TODO Auto-generated method stub
		for(int i=start;i<=end;i++){
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
