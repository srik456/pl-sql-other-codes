package thread1;

public class Couple {
    private String husband,wife;
    public Couple(String husband, String wife) {
		super();
		this.husband = husband;
		this.wife = wife;
	}
    public synchronized void show(){
    	synchronized(this){
    	System.out.println(husband);
    	System.out.println(wife);
    }
    
}
}
