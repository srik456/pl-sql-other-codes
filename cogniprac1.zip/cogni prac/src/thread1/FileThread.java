package thread1;
public class FileThread extends Thread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CountWords cw=new CountWords();
		CharacterCount cc=new CharacterCount();
	
	    cw.start();
		cc.start();

	}

}
