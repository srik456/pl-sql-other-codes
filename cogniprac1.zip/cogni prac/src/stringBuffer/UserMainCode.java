package stringBuffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date; 
	public class UserMainCode {  
	@SuppressWarnings("deprecation")
	public static void displayDate (String date){
	    DateFormat sdf = new SimpleDateFormat("MMM d, yyyy");

	    	try {
				// Convert String to Date in java
				Date today = sdf.parse(date);
				System.out.println(today.getYear()+"-"+today.getMonth()+"-"+today.getDate());
	             }
	        catch (ParseException e) {
	    		e.printStackTrace();
			}
	    

	   
	   }
	}
	 

