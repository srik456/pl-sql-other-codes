package stringBuffer;

public class StringBufferDemo {
	static String reverse(String s){
		StringBuffer sb=new StringBuffer(s);
		sb.reverse();
		s=sb.toString();
		return s;
	}
	public static void main(String[] args){
		String s="DEF";
		System.out.println(reverse(s));
		StringBuffer sb=new StringBuffer();
		sb.append("Hello").append("World");
		System.out.println(sb);
		String name="srikanth narayanan";
		/*StringBuffer sb1=new StringBuffer(name);
		StringBuffer sb2=new StringBuffer();
		String s2=name.substring(0,name.indexOf(' '));
	    sb2.append(Character.toUpperCase(s2.charAt(0))).append(s2.substring(1));
	    System.out.println(sb2);
	    String s3=name.substring(0, name.indexOf(' '));
	    sb1*/
		String n[]=name.split("//s");
		for(int i=0;i<n.length;i++){
			
		}
	}

}
