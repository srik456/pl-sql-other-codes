import java.util.*;
import java.text.*;
public class DateProb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar c1=Calendar.getInstance();
		Calendar c2=Calendar.getInstance();
		long dif1;
		c1.set(2004, 12, 21);
		c2.set(2025, 2, 23);
        //dif1=Math.abs((c1.get(Calendar.MONTH)-(c2.get(Calendar.MONTH)));
		int mdiff=c1.get(Calendar.MONTH)-c2.get(Calendar.MONTH);
		int ydiff=c1.get(Calendar.YEAR)-c2.get(Calendar.YEAR);
		dif1=Math.abs(mdiff)+(12*(Math.abs(ydiff)));
        
        
        System.out.println(dif1);
		

	}

}
