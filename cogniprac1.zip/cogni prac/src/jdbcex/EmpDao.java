package jdbcex;
import java.util.*;
public interface EmpDao {
	

	boolean insertRec(Emp emp);
	boolean deleteRec(int empno);
	boolean SearchRec(int empno);
    Emp getEmployee(int empno);
    ArrayList<Emp> getAllRec();
    boolean updateRec(int empno,String name);
    boolean updateRec(int empno,int sal);
    boolean updateRec(int empno,String name,int sal);
    
}
