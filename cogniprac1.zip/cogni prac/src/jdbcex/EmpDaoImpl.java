package jdbcex;
import java.sql.*;
import java.util.ArrayList;
public class EmpDaoImpl implements EmpDao{


	public boolean insertRec(Emp emp) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		if(con!=null){
			try{
				Statement st=con.createStatement();
				String query="insert into emp values("+emp.getEmpno()+",'"+emp.getName()+"',"+emp.getSal()+")";
				int rec=st.executeUpdate(query);
				if(rec==1){
					return true;
				}
			}catch(SQLException e){
				System.out.println(e);
			}
			
		}
		return false;
	}

	/*public boolean insertRec(int empno, String name, int salary) {
		// TODO Auto-generated method stub
		return false;
	}*/
	public boolean deleteRec(int empno){
		Connection con=null;
		con=JdbcConnection.getConnection();
		try{
			Statement st=con.createStatement();
			String query="delete from emp where empno="+empno;
			int rec=st.executeUpdate(query);
			if(rec==1){
				return true;
			}
			
		}catch(SQLException e){
			System.out.println(e);
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public boolean SearchRec(int empno){
		Connection con=null;
		con=JdbcConnection.getConnection();
		try{
			Statement st=con.createStatement();
			String query="select empno from emp where empno="+empno;
			ResultSet rs=st.executeQuery(query);
			if(rs.next()){
				return true;
			}
			
		}catch(SQLException e){
			System.out.println(e);
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public Emp getEmployee(int empno){
		Connection con=null;
		con=JdbcConnection.getConnection();
		try{
			Statement st=con.createStatement();
			String query="select * from emp where empno="+empno;
			ResultSet rs=st.executeQuery(query);
			rs.next();
			int m_empno=rs.getInt(1);
			String m_name=rs.getString(2);
			int sal=rs.getInt(3);
			Emp e=new Emp(m_empno,m_name,sal);
			return e;
		}catch(SQLException e){
			System.out.println(e);
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
		
		
	}

	@Override
	public ArrayList<Emp> getAllRec() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateRec(int empno, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRec(int empno, int sal) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRec(int empno, String name, int sal) {
		// TODO Auto-generated method stub
		return false;
	}

}
