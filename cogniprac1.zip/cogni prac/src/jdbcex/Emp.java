package jdbcex;

public class Emp {
	private int empno;
	private String name;
	private int sal;
	public Emp(int empno, String name, int sal) {
		super();
		this.empno = empno;
		this.name = name;
		this.sal = sal;
	}
	public Emp() {
		super();
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "empno=" + empno + ", name=" + name + ", sal=" + sal;
	}
	

}
