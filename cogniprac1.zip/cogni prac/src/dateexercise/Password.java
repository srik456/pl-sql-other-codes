package dateexercise;
import java.util.*;
import java.util.regex.*;
public class Password {

	static boolean checkUpper(String password){
		boolean flag=false;
		for(char c:password.toCharArray()){
			if(Character.isUpperCase(c)){
				flag=true;
			}
		}
		return flag;
	}
	static void validatepasssword(String pass){
		boolean flag=false;
		if(pass.length()<8){
			System.out.println("Invalid password length,Enter length >= 8");
		}
		else if(checkSpl(pass)==false){
			System.out.println("Plz enter special characters in your password");
		}
		else if(checkUpper(pass)==true){
			System.out.println("Plz enter password in lowercase");
		}
		else{
			System.out.println("Password Accepted");
		}
	}
	static boolean checkSpl(String password){
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(password);
	    boolean flag=false;
	      if(!matcher.matches()) {
	           flag=true;
	      } else {
	           flag=false;
	      }
	      return flag;
	 
	  }
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Password p=new Password();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter password");
		String pass=s.next();
		p.validatepasssword(pass);
		
		

	}

}
