package dateexercise;

import java.util.*;

public class Calendar1 {
	public static void main(String args[]){
		Calendar c=Calendar.getInstance();
		Calendar c1=Calendar.getInstance();
		c.set(2019, 1, 21, 14, 30);
		c.set(Calendar.PM, 2);
		System.out.println(c);
		
	}

}
