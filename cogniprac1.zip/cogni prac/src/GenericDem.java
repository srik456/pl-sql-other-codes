
public class GenericDem<T> {
 T x;


 public GenericDem() {
	super();
}

public GenericDem(T x) {
	super();
	this.x = x;
}

public T getX() {
	return x;
}

public void setX(T x) {
	this.x = x;
}
 
	
}
