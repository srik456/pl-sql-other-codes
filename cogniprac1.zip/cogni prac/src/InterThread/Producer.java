package InterThread;

public class Producer extends Thread{
	Basket b;

	
	public Producer() {
		super();
	}
	public Producer(Basket b) {
		super();
		this.b = b;
	}
	public void run(){
		for(int i=1;i<10;i++){
			b.setNum(i);
		}
	}
}
