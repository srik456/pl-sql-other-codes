import java.time.*;
public class LocalDateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate currentDate=LocalDate.now();
		LocalDate indepedenceday=LocalDate.of(1947, 7, 15);
		
		

	}

}
