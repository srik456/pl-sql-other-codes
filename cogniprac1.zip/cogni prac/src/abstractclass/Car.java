package abstractclass;

public class Car extends Vehicle{
	private int noOfSeats;

	public Car() {
		super();
	}

	public Car(String regNo, String vMake, String color, int noOfSeats) {
		super(regNo, vMake, color);
		this.noOfSeats = noOfSeats;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public void start(){
		System.out.println("Car has started");
	}
	public void stop(){
		System.out.println("Car has stopped");
	}
	public String toString(){
		return super.toString()+" "+noOfSeats;
	}
	

}
