package abstractclass;

public class Truck extends Vehicle {
	private int loadcapacity;

	public Truck() {
		super();
	}

	public Truck(String regNo, String vMake, String color, int loadcapacity) {
		super(regNo, vMake, color);
		this.loadcapacity = loadcapacity;
	}

	public int getLoadcapacity() {
		return loadcapacity;
	}

	public void setLoadcapacity(int loadcapacity) {
		this.loadcapacity = loadcapacity;
	}
	public void start(){
		System.out.println("Truck has Started");
	}
	public void stop(){
		System.out.println("Truck has stopped");
	}
	public String toString(){
		return super.toString()+" "+loadcapacity;
	}

}
