package setproblems;
import java.util.*;
public class Tog {
    public static boolean isPrime(int num){
    	if(num==1||num==0){
    		return false;
    	}
    	for(int i=2;i<num;i++){
    		if(num%i==0){
    			return false;
    		}
    	}
    	return true;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in);
    int rem=0,temp=0,count=0,n,m;
    n=sc.nextInt();
    m=sc.nextInt();
    for(int i=n;i<=m;i++){
    	temp=i;
    	count=0;
    	while(temp!=0){
    		rem=temp%10;
    		if(isPrime(rem)==true){
    			count++;
    		}
    		temp /=10;
    	}
    	if(count==2){
    		System.out.print(" "+i);
    	}
    }
	}

}
