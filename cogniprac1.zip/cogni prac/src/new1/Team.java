package new1;

public class Team {
private String name;
private long numberOfmatches;

public Team() {
	super();
}
public Team(String name, long numberOfmatches) {
	super();
	this.name = name;
	this.numberOfmatches = numberOfmatches;
}
public String getName() {
	return name;
}
@Override
public String toString() {
	return "Team [name=" + name + ", numberOfmatches=" + numberOfmatches + "]";
}
public void setName(String name) {
	this.name = name;
}
public long getNumberOfmatches() {
	return numberOfmatches;
}
public void setNumberOfmatches(long numberOfmatches) {
	this.numberOfmatches = numberOfmatches;
}


}
