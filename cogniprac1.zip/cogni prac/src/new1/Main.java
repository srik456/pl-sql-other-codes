package new1;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String rc;
        int ra;
        String con;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		TreeSet<Revenue> rts=new TreeSet<>();
        Revenue r=new Revenue();
        try {
			do{
				System.out.println("Enter the revenue category");
				rc=br.readLine();
				System.out.println("Enter revenue amount");
				ra=Integer.parseInt(br.readLine());
				r.setRevenueCategory(rc);
				r.setAmount(ra);
				rts.add(r);
				System.out.println("Do you want to continue(yes/no):");
				con=br.readLine();
			}while(con=="yes"||con=="YES");
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("Top spending categories");
        System.out.println(String.format("%-15s%-15s","Category", "Amount"));
        Iterator it;
        it=rts.descendingIterator();
        while (it.hasNext()) {
            System.out.println(it.next());
         }
        
      }
        

}
