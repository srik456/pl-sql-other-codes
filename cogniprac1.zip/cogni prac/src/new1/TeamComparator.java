package new1;
import java.util.*;
public class TeamComparator implements Comparator<Team>{

	@Override
	public int compare(Team o1, Team o2) {
		// TODO Auto-generated method stub
		return (int)(o1.getNumberOfmatches()-o2.getNumberOfmatches());
	}



}
